cd /Volumes/frankenhdd/HackerBot
node index.js
